<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Pharmacie Ounissi Ali - Gestionnaire des taches</title>
    
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/semantic.min.css')); ?>">
        <script src="<?php echo e(asset('js/semantic.min.js')); ?>"></script>
        
    </head>
    <body>
        <div id="master" ></div>
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    </body>
</html><?php /**PATH C:\Users\acer\ali_task\ali_task\resources\views/welcome.blade.php ENDPATH**/ ?>